HW3 Readme


Execution:
Use the following commands to run the file:

1. javac Sat.java  —> Compile
2. java Sat <input_file>.txt <output_file>.txt  —> run 

Requirements:

Java 1.5 or greater

Note: please use the name of the file Sat  to compile and run the code.