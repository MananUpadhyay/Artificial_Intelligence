MiniMax Algorithm ReadMe

Execution:
Use the following commands to run the file:

1. javac MiniMax.java  —> Compile
2. java MiniMax <input_file>.txt <output_file>.txt  —> run 

Requirements:

Java 1.4 or greater

Note: please use the name of the file MiniMax  to compile and run the code.